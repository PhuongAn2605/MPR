package fit.hanu.hellojapan;

public class Sound {
    private int soundId;

    public Sound(int soundId) {
        this.soundId = soundId;
    }

    public int getSoundId() {
        return soundId;
    }

    public void setSoundId(int soundId) {
        this.soundId = soundId;
    }
}
